Research Awards 

After nomination approved will show the below fields

1. Complete Bio-data of the applicant(Max: 1.5MB) pdf format
2. In Order of Importance list of 10 best papers of the applicant highlighting the important discoveries/contribution described in them briefly.(Max 1 MB)

3. Statement of Research Achievements, if any, on which any Award has already been Received by the Applicant. Please also upload brief citations on the research works for which the applicant has already received the awards (Max: 1 MB)
4. Signed details of the excellence in research work for which the Sun Pharma Research Award is claimed, including references and illustrations. The candidate should duly sign on the details. (Max: 2.5 MB)
5. Two specific publications/research papers of the applicant relevent to the research work mentioned above.(Max: 2.5MB)
6. A signed statement by the applicant that the research work under reference has not been given any award. The applicant should also indicate the extent of the contribution of the others associated with the research and he/she should clearly acknowledge his/her achievements (Max: 500KB)     
7. Citation on the Research Work of the Applicant duly signed by the Naminator(Max: 300 KB)