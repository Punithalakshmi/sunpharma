<div class="loginsection">
<div class="login_wrapper">
<div class="animate form login_form">
    <section class="login_content">
        Access Denied
        <div class="row">
                <div class="col-md-12" style="text-align: center;">
                    <a class="btn btn-primary btn-sm d-block create-account w-100" href="<?=base_url();?>/<?=$uri;?>/login">LOGIN</a>         
                 </div>
            </div>
    </section>
</div>
</div>
</div>