
    <section class="heroInner" style="background: #fff url(<?=base_url();?>/frontend/assets/img/HUMILITY.jpg) center left no-repeat;">
        <div class="container">
            <h1 class="fs-1 fw-bold text-capitalize fw-normal p-3 m-0 d-inline-block" style="color: var(--theme-orange);">Success</h1>
        </div>
    </section>
    <section class="py-5">
        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center successseccont">
                    
                   <div class="successsec badge badge-success"> <p>
                        Thank you. Your application is under review , you should receive an email soon! 
                    </p></div>
                    
                </div>
            </div>
        </div>
    </section>