<?php
 
if ( ! function_exists('getUserRole'))
{
    function getUserRole()
    {
        
    }
}

if ( ! function_exists('getUserRole'))
{
    function getUserRole()
    {
        
    }
}


if ( ! function_exists('getUserRole'))
{
    function getUserRole()
    {
        
    }
}




?>